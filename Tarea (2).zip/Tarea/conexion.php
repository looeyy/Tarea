<?php

$servidor= "localhost";
$nombre= "carnet";
$usuario= "root";
$contraseña= "";

$conexion= mysqli_connect($servidor, $usuario, $contraseña, $nombre);

if($conexion->connect_error){
    die("Error de conexión: ".$conexion->connect_error);
}
echo("Conexión Establecida!"); 
echo "<br>";
?>