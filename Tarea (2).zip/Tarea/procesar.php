<?php

require_once "conexion.php";

    $nombre= $_POST['nombres'];
    $apellidoP= $_POST['apellidoP'];
    $apellidoM= $_POST['apellidoM'];
    $edad= $_POST['edad'];
    $fecha= $_POST['fecha'];
    $nacionalidad= $_POST['nacionalidad'];
    $lugar= $_POST['lugar'];
    $rut= $_POST['rut'];
    $profesion= $_POST['profesion'];
    $sexo= $_POST['sexo'];
    $dona= $_POST['dona'];
    $obj_direccion = "img/";
    $obj_archivo = $obj_direccion . basename($_FILES["archivo"]["name"]);
    move_uploaded_file($_FILES["archivo"]["tmp_name"], $obj_archivo);
    $foto = mysqli_real_escape_string($conexion, $obj_archivo);


function crear_alumno($conexion, $nombre, $apellidoP, $apellidoM, $edad, $fecha, $nacionalidad, $lugar, $rut, $profesion, $sexo, $dona, $foto){
    $sql = "INSERT INTO datos (nombres, apellidoP, apellidoM, edad, fecha, nacionalidad, lugar, rut, profesion, sexo, dona, foto, documento) VALUES ('$nombre', '$apellidoP', '$apellidoM', '$edad', '$fecha', '$nacionalidad', '$lugar', '$rut', '$profesion', '$sexo', '$dona', '$foto', NULL)";

    // Ejecutar la consulta 
    $resultado = mysqli_query($conexion, $sql);
    if ($resultado){
        echo "Alumno ingresado correctamente";
        return True;
    }else{
        return FALSE;
    }
}



function validarRut($rut)
{
    $rut = preg_replace('/[^k0-9]/i', '', $rut);
    $dv  = substr($rut, -1);
    $numero = substr($rut, 0, strlen($rut)-1);
    $i = 2;
    $suma = 0;
    foreach(array_reverse(str_split($numero)) as $v)
    {
        if($i==8)
            $i = 2;

        $suma += $v * $i;
        ++$i;
    }

    $dvr = 11 - ($suma % 11);
    
    if($dvr == 11)
        $dvr = 0;
    if($dvr == 10)
        $dvr = 'K';

    if($dvr == strtoupper($dv))
        return true;
    else
        return false;
}

if(!(validarRut($rut))){
    die("Error. Rut invalido");
}
crear_alumno($conexion, $nombre, $apellidoP, $apellidoM, $edad, $fecha, $nacionalidad, $lugar, $rut, $profesion, $sexo, $dona, $foto);

$conexion->close();
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<form action="index.php" method="POST" enctype="multipart/form-data">
    <button type="submit" class="btn btn-outline-success">Seguir ingresando</button>
</form>
<form action="personas.php  " method="POST" enctype="multipart/form-data">
    <button type="submit" class="btn btn-outline-info">Visualizar informacion</button>
</form>