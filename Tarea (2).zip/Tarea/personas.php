<?php require_once "conexion.php"; ?> 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col">
        <h1>Carnets</h1>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <table class="table">
          <thead>
            <tr>
              <th>Nombres</th>
              <th>Apellidos</th>
              <th>Rut</th>
              <th>Generar carnet</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $sql = "SELECT * FROM datos";
              $resultado = $conexion->query($sql);

              while ($col = $resultado->fetch_array()) {
                echo '<tr>';
                echo '<td>' . $col[0] . '</td>';
                echo '<td>' . $col[1] . ' ' . $col[2] . '</td>';
                echo '<td>' . $col[7] . '</td>';
                echo '<td><a href="tarjeta.php?rut=' . $col[7] . '" class="btn btn-primary">Generar</a></td>';
                echo '</tr>';
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
<?php $conexion->close(); ?>