<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
            <div class="row">
                <div class="col">
                    <h1 class = "text-center mb-4">Carnet de identidad</h1>

        <form action="procesar.php" method="POST" enctype="multipart/form-data">

            <label for="nombres" class="form-label">Nombres:</label>
            <input type="text" name="nombres" id="nombres" class="form-control">
            <br>

            <label for="apellidoP">Apellido Paterno:</label>
            <input type="text" name="apellidoP" id="apellidoP" class="form-control">
            <br>

            <label for="apellidoM">Apellido Materno:</label>
            <input type="text" name="apellidoM" id="apellidoM" class="form-control">
            <br>

            <label for="edad" class="form-label">Edad:</label>
            <input type="number" name="edad" id="edad" class="form-control">
            <br>
            <label for="fecha">Fecha de Nacimiento:</label>
            <input type="date" name="fecha" id="fecha" class="form-control">
            <br>
            <div class="container mt-5">
            <label for="nacionalidad">Nacionalidad:</label>
            <select class="form-select" id="nacionalidad" name="nacionalidad">
                <option value="cl">Chilena</option>
                 <option value="ar">Argentina</option>
                 <option value="pe">Peruana</option>
                 <option value="co">Colombiana</option>
                 <option value="o">Otra</option>
             </select>
             </div>
            <br>
            <label for="lugar">Lugar de Nacimiento:</label>
            <input type="text" name="lugar" id="lugar" class="form-control">
            <br>
            <label for="rut">Rut:</label>
            <input type="text" name="rut" id="rut" class="form-control" placeholder="xx.xxx.xxx-x">
            <br>
            <label for="profesion">Profesion:</label>
            <input type="text" name="profesion" id="profesion" class="form-control">
            <br>
            <p>Genero:</p>
                <input type="radio" name="sexo" value="F"> Femenino<br>
                <input type="radio" name="sexo" value="M"> Masculino<br>
                <input type="radio" name="sexo" value="X"> No Binario<br>
            <br>
            <p>¿Esta inscrito en el registro de discapacidad?</p>
                <input type="radio" name="disca" value="Si"> Si<br>
                <input type="radio" name="disca" value="No"> No<br>
            <br>
            <p>¿Es usted donante?</p>
                <input type="radio" name="dona" value="Si"> Si<br>
                <input type="radio" name="dona" value="No"> No<br>
            <br>
            <label for="foto">Foto Carnet</label>
            <input type="file" name="archivo" id="archivo" class="form-control">
            <br>
            <label for=""></label>
            <input type="submit" value="Enviar" class="btn btn-outline-primary btn-lg">
         </form>
                </div>
            </div>
        </div>

</body>
</html>